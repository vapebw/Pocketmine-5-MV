<?php

/*
 * This file is part of BedrockProtocol.
 * Copyright (C) 2014-2022 PocketMine Team <https://github.com/pmmp/BedrockProtocol>
 *
 * BedrockProtocol is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 */

declare(strict_types=1);

namespace pocketmine\network\mcpe\protocol\types\biome\chunkgen;

use pmmp\encoding\Byte;
use pmmp\encoding\ByteBufferReader;
use pmmp\encoding\ByteBufferWriter;
use pmmp\encoding\VarInt;
use pocketmine\network\mcpe\protocol\ProtocolInfo;
use pocketmine\network\mcpe\protocol\serializer\CommonTypes;
use function count;

final class BiomeDefinitionChunkGenData{

	/**
	 * @param BiomeReplacementData[] $replacementsData
	 */
	public function __construct(
		private ?BiomeClimateData $climate,
		private ?BiomeConsolidatedFeaturesData $consolidatedFeatures,
		private ?BiomeMountainParamsData $mountainParams,
		private ?BiomeSurfaceMaterialAdjustmentData $surfaceMaterialAdjustment,
		private ?BiomeSurfaceMaterialData $surfaceMaterial,
		private bool $defaultOverworldSurface,
		private bool $swampSurface,
		private bool $frozenOceanSurface,
		private bool $theEndSurface,
		private ?BiomeMesaSurfaceData $mesaSurface,
		private ?BiomeCappedSurfaceData $cappedSurface,
		private ?BiomeOverworldGenRulesData $overworldGenRules,
		private ?BiomeMultinoiseGenRulesData $multinoiseGenRules,
		private ?BiomeLegacyWorldGenRulesData $legacyWorldGenRules,
		private ?array $replacementsData,
		private ?int $villageType,
	){}

	public function getClimate() : ?BiomeClimateData{ return $this->climate; }

	public function getConsolidatedFeatures() : ?BiomeConsolidatedFeaturesData{ return $this->consolidatedFeatures; }

	public function getMountainParams() : ?BiomeMountainParamsData{ return $this->mountainParams; }

	public function getSurfaceMaterialAdjustment() : ?BiomeSurfaceMaterialAdjustmentData{ return $this->surfaceMaterialAdjustment; }

	public function getSurfaceMaterial() : ?BiomeSurfaceMaterialData{ return $this->surfaceMaterial; }

	public function hasDefaultOverworldSurface() : bool{ return $this->defaultOverworldSurface; }

	public function hasSwampSurface() : bool{ return $this->swampSurface; }

	public function hasFrozenOceanSurface() : bool{ return $this->frozenOceanSurface; }

	public function hasTheEndSurface() : bool{ return $this->theEndSurface; }

	public function getMesaSurface() : ?BiomeMesaSurfaceData{ return $this->mesaSurface; }

	public function getCappedSurface() : ?BiomeCappedSurfaceData{ return $this->cappedSurface; }

	public function getOverworldGenRules() : ?BiomeOverworldGenRulesData{ return $this->overworldGenRules; }

	public function getMultinoiseGenRules() : ?BiomeMultinoiseGenRulesData{ return $this->multinoiseGenRules; }

	public function getLegacyWorldGenRules() : ?BiomeLegacyWorldGenRulesData{ return $this->legacyWorldGenRules; }

	/**
	 * @return BiomeReplacementData[]
	 */
	public function getReplacementsData() : ?array{ return $this->replacementsData; }

	public function getVillageType() : ?int{ return $this->villageType; }

	public static function read(ByteBufferReader $in, int $protocolId) : self{
		$climate = CommonTypes::readOptional($in, fn() => BiomeClimateData::read($in, $protocolId));
		$consolidatedFeatures = CommonTypes::readOptional($in, fn() => BiomeConsolidatedFeaturesData::read($in));
		$mountainParams = CommonTypes::readOptional($in, fn() => BiomeMountainParamsData::read($in));
		$surfaceMaterialAdjustment = CommonTypes::readOptional($in, fn() => BiomeSurfaceMaterialAdjustmentData::read($in));
		$surfaceMaterial = CommonTypes::readOptional($in, fn() => BiomeSurfaceMaterialData::read($in));
		if($protocolId >= ProtocolInfo::PROTOCOL_1_21_111){
			$defaultOverworldSurface = CommonTypes::getBool($in);
		}
		$swampSurface = CommonTypes::getBool($in);
		$frozenOceanSurface = CommonTypes::getBool($in);
		$theEndSurface = CommonTypes::getBool($in);
		$mesaSurface = CommonTypes::readOptional($in, fn() => BiomeMesaSurfaceData::read($in));
		$cappedSurface = CommonTypes::readOptional($in, fn() => BiomeCappedSurfaceData::read($in));
		$overworldGenRules = CommonTypes::readOptional($in, fn() => BiomeOverworldGenRulesData::read($in));
		$multinoiseGenRules = CommonTypes::readOptional($in, fn() => BiomeMultinoiseGenRulesData::read($in));
		$legacyWorldGenRules = CommonTypes::readOptional($in, fn() => BiomeLegacyWorldGenRulesData::read($in));
		if($protocolId >= ProtocolInfo::PROTOCOL_1_21_120){
			$replacementsData = CommonTypes::readOptional($in, function(ByteBufferReader $in) : array{
				$count = VarInt::readUnsignedInt($in);
				$result = [];
				for($i = 0; $i < $count; ++$i){
					$result[] = BiomeReplacementData::read($in);
				}
				return $result;
			});

			if($protocolId >= ProtocolInfo::PROTOCOL_1_26_0){
				$villageType = CommonTypes::readOptional($in, fn() => Byte::readUnsigned($in));
			}
		}

		return new self(
			$climate,
			$consolidatedFeatures,
			$mountainParams,
			$surfaceMaterialAdjustment,
			$surfaceMaterial,
			$defaultOverworldSurface ?? false,
			$swampSurface,
			$frozenOceanSurface,
			$theEndSurface,
			$mesaSurface,
			$cappedSurface,
			$overworldGenRules,
			$multinoiseGenRules,
			$legacyWorldGenRules,
			$replacementsData ?? null,
			$villageType ?? null
		);
	}

	public function write(ByteBufferWriter $out, int $protocolId) : void{
		CommonTypes::writeOptional($out, $this->climate, fn(ByteBufferWriter $out, BiomeClimateData $v) => $v->write($out, $protocolId));
		CommonTypes::writeOptional($out, $this->consolidatedFeatures, fn(ByteBufferWriter $out, BiomeConsolidatedFeaturesData $v) => $v->write($out));
		CommonTypes::writeOptional($out, $this->mountainParams, fn(ByteBufferWriter $out, BiomeMountainParamsData $v) => $v->write($out));
		CommonTypes::writeOptional($out, $this->surfaceMaterialAdjustment, fn(ByteBufferWriter $out, BiomeSurfaceMaterialAdjustmentData $v) => $v->write($out));
		CommonTypes::writeOptional($out, $this->surfaceMaterial, fn(ByteBufferWriter $out, BiomeSurfaceMaterialData $v) => $v->write($out));
		if($protocolId >= ProtocolInfo::PROTOCOL_1_21_111){
			CommonTypes::putBool($out, $this->defaultOverworldSurface);
		}
		CommonTypes::putBool($out, $this->swampSurface);
		CommonTypes::putBool($out, $this->frozenOceanSurface);
		CommonTypes::putBool($out, $this->theEndSurface);
		CommonTypes::writeOptional($out, $this->mesaSurface, fn(ByteBufferWriter $out, BiomeMesaSurfaceData $v) => $v->write($out));
		CommonTypes::writeOptional($out, $this->cappedSurface, fn(ByteBufferWriter $out, BiomeCappedSurfaceData $v) => $v->write($out));
		CommonTypes::writeOptional($out, $this->overworldGenRules, fn(ByteBufferWriter $out, BiomeOverworldGenRulesData $v) => $v->write($out));
		CommonTypes::writeOptional($out, $this->multinoiseGenRules, fn(ByteBufferWriter $out, BiomeMultinoiseGenRulesData $v) => $v->write($out));
		CommonTypes::writeOptional($out, $this->legacyWorldGenRules, fn(ByteBufferWriter $out, BiomeLegacyWorldGenRulesData $v) => $v->write($out));
		if($protocolId >= ProtocolInfo::PROTOCOL_1_21_120){
			CommonTypes::writeOptional($out, $this->replacementsData, function(ByteBufferWriter $out, array $v) : void{
				VarInt::writeUnsignedInt($out, count($v));
				foreach($v as $item){
					$item->write($out);
				}
			});

			if($protocolId >= ProtocolInfo::PROTOCOL_1_26_0){
				CommonTypes::writeOptional($out, $this->villageType, fn(ByteBufferWriter $out, int $v) => Byte::writeUnsigned($out, $v));
			}
		}
	}
}
